// ConsoleApplication1.cpp : Este archivo contiene la función "main". La ejecución del programa comienza y termina ahí.
//

// Usuario.h
// Usuario.cpp
#include "Usuario.h"
#include <fstream>
#include <iostream>

using namespace std;

// Constructor para inicializar el usuario
Usuario::Usuario(const string& nombre, const string& contrasena)
    : nombre(nombre), contrasena(contrasena) {}

// Mostrar los datos del usuario
void Usuario::mostrarDatos() const {
    cout << "Usuario: " << nombre << endl;
    cout << "Contraseña: " << 12345 << endl;
}

// Escribir los datos del usuario en un archivo binario
void Usuario::escribirEnArchivo(ofstream& archivo) const {
    size_t tamNombre = nombre.size();
    size_t tamContrasena = contrasena.size();

    archivo.write(reinterpret_cast<const char*>(&tamNombre), sizeof(tamNombre));
    archivo.write(nombre.c_str(), tamNombre);

    archivo.write(reinterpret_cast<const char*>(&tamContrasena), sizeof(tamContrasena));
    archivo.write(contrasena.c_str(), tamContrasena);
}

// Leer los datos de un usuario desde un archivo binario
Usuario Usuario::leerDesdeArchivo(ifstream& archivo) {
    size_t tamNombre, tamContrasena;
    string nombre, contrasena;

    archivo.read(reinterpret_cast<char*>(&tamNombre), sizeof(tamNombre));
    nombre.resize(tamNombre);
    archivo.read(&nombre[0], tamNombre);

    archivo.read(reinterpret_cast<char*>(&tamContrasena), sizeof(tamContrasena));
    contrasena.resize(tamContrasena);
    archivo.read(&contrasena[0], tamContrasena);

    return Usuario(nombre, contrasena);
}


// Ejecutar programa: Ctrl + F5 o menú Depurar > Iniciar sin depurar
// Depurar programa: F5 o menú Depurar > Iniciar depuración

// Sugerencias para primeros pasos: 1. Use la ventana del Explorador de soluciones para agregar y administrar archivos
//   2. Use la ventana de Team Explorer para conectar con el control de código fuente
//   3. Use la ventana de salida para ver la salida de compilación y otros mensajes
//   4. Use la ventana Lista de errores para ver los errores
//   5. Vaya a Proyecto > Agregar nuevo elemento para crear nuevos archivos de código, o a Proyecto > Agregar elemento existente para agregar archivos de código existentes al proyecto
//   6. En el futuro, para volver a abrir este proyecto, vaya a Archivo > Abrir > Proyecto y seleccione el archivo .sln
